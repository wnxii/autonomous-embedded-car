#ifndef SERVER_SOCKET_H
#define SERVER_SOCKET_H

extern int remote_target_speed;
extern int remote_steering;

void init_server_socket(void);

#endif // SERVER_SOCKET_H
