#ifndef barcode_scanner_with_client_socket_H
#define barcode_scanner_with_H

void init_barcode_wifi();

extern volatile bool connected;


#endif