#ifndef main_H
#define main_H

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "../motor/motor.h"

#define SAFETY_THRESHOLD 10.0f // 10 cm safety threshold for ultrasonic sensor

#endif