#ifndef main_H
#define main_H

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "../motor/motor.h"


#endif